import java.util.ArrayList;
import java.util.List;

public class FamilyTree {

    private List<Humans> Tree;

    public FamilyTree(List<Humans> Tree) {
        this.Tree = Tree;
    }

    public FamilyTree() {
        this(new ArrayList<>());
    }

    public List<Humans> getTree() {
        return Tree;
    }

    public void setTree(List<Humans> tree) {
        Tree = tree;
    }

    public void addHuman(Humans hum) {
        Tree.add(hum);
    }
}


