public class Main {
    public static void main(String[] args) {

        FamilyTree FamilyTree = new FamilyTree();


        Humans human1 = new Humans("Masha", "female", , 0);


    }
}m