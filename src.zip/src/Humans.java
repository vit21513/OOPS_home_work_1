import java.util.ArrayList;
import java.util.List;


public class Humans {


    String name;
    String gender;
    Humans father;
    Humans mother;


    List<Humans> children = new ArrayList<>();

//    Humans mother = new Humans();


    public Humans(String name, String gender, Humans father, Humans mother) {
        this.name = name;
        this.gender = gender;
        this.father = father;
        this.mother = mother;
        father.children.add(this);
        mother.children.add(this);


    }
}
